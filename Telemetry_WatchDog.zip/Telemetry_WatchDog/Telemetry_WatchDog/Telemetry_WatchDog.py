
"""
open_report.py
Telemetry Watchdog - Trend Detectives: Ethical Hackers in Space

Opens an HTML report in the default web browser.

Usage:
    python open_report.py
    python open_report.py my_report.html

Requirements:
    Python 3.8+
    No external packages required.

Security:
    - Only existing regular files are accepted.
    - Only .html and .htm extensions are allowed.
    - Paths are converted to absolute file URLs.
    - No shell commands are executed.
"""

import sys
import webbrowser
from pathlib import Path


def has_html_extension(filename):
    """
    Check whether the filename ends in .html or .htm.
    Case-insensitive.
    """
    return Path(filename).suffix.lower() in (".html", ".htm")


def is_regular_file(filename):
    """
    Check whether the path exists and is a regular file.
    """
    try:
        return Path(filename).is_file()
    except (OSError, ValueError):
        return False


def full_path_of(filename):
    """
    Convert a relative path to an absolute path.
    Return None if resolution fails.
    """
    try:
        return Path(filename).resolve(strict=True)
    except (OSError, RuntimeError, ValueError):
        return None


def current_folder():
    """
    Return the current working directory.
    """
    try:
        return str(Path.cwd())
    except OSError:
        return "(unknown)"


def open_in_browser(filepath):
    """
    Open the HTML file using the default browser.

    Uses a file:// URL instead of a shell command
    to prevent shell command injection.
    """
    try:
        file_url = filepath.as_uri()
        return webbrowser.open(file_url, new=2)
    except (OSError, ValueError, webbrowser.Error):
        return False


def main():
    # Check command-line arguments.
    if len(sys.argv) > 2:
        print(
            "Usage: python open_report.py [file.html]",
            file=sys.stderr
        )
        return 2

    # Default report filename.
    filename = (
        sys.argv[1]
        if len(sys.argv) == 2
        else "dashboard.html"
    )

    # Check 1: File exists and is a regular file.
    if not is_regular_file(filename):
        print(
            f"Error: report not found: {filename}\n"
            f"I looked in this folder: {current_folder()}\n"
            "Copy dashboard.html into that folder, "
            "or create it there with:\n"
            "    python make_dashboard.py",
            file=sys.stderr
        )
        return 1

    # Check 2: Only HTML files are allowed.
    if not has_html_extension(filename):
        print(
            f"Error: not an HTML file: {filename}",
            file=sys.stderr
        )
        return 1

    # Check 3: Resolve the absolute file path.
    full_path = full_path_of(filename)

    if full_path is None:
        print(
            f"Error: could not read the full path of {filename}",
            file=sys.stderr
        )
        return 1

    # Open report in browser.
    print(f"Opening {full_path} ...")

    if not open_in_browser(full_path):
        print(
            "Error: could not open a web browser.\n"
            "Open the file yourself by double-clicking it.",
            file=sys.stderr
        )
        return 1

    print("Done. Browser opening was requested successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

